//
//  ItemListRouter.swift
//  ViperTestSwiftUI
//
//  Created by Waleed Waheed Khan on 20/04/2021.
//

import SwiftUI

class ItemListRouter {
    func makeItemDetailView(for item: Item) -> some View {
        ItemDetailView(
            presenter: ItemDetailPresenter(
                interactor: ItemDetailInteractor(
                    item: item
                )
            )
        )
    }
}
