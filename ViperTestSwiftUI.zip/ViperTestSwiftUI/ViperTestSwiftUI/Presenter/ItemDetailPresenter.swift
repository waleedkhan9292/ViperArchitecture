//
//  ItemDetailPresenter.swift
//  ViperTestSwiftUI
//
//  Created by Waleed Waheed Khan on 21/04/2021.
//

import SwiftUI
import Combine

class ItemDetailPresenter {
    
    
    //MARK:- PUBLIC PROPERTIES
    
    //MARK:- PRIVATE PROPERTIES
    private var interactor: ItemDetailInteractor
    private var cancellables = Set<AnyCancellable>()
    private var router = ItemListRouter()
    
    //MARK:- PUBLIC OBSERVERS
    @Published var item: Item?
    
    //MARK:- CONSTRUCTOR
    init(interactor: ItemDetailInteractor) {
        self.interactor = interactor
        setupListener()
    }
}

//MARK:- METHODS
extension ItemDetailPresenter {
    //MARK:- PUBLIC METHODS
    
    //MARK:- ROUTER METHODS
    func linkBuilder<Content: View>(for item: Item, @ViewBuilder content: () -> Content) -> some View {
        NavigationLink(destination: router.makeItemDetailView(for: item)) {
            content()
        }
        .buttonStyle(PlainButtonStyle())
    }
    
    //MARK:- PRIVATE METHODS
    private func setupListener() {
        interactor.$item
            .assign(to: \.item, on: self)
            .store(in: &cancellables)
    }
}


//MARK:- OBSERVABLE OBJECT
extension ItemDetailPresenter: ObservableObject { }
