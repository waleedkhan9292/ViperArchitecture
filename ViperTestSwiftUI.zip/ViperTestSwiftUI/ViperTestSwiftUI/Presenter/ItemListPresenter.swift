//
//  ItemListPresenter.swift
//  ViperTestSwiftUI
//
//  Created by Waleed Waheed Khan on 20/04/2021.
//

import SwiftUI
import Combine

class ItemListPresenter {
    
    
    //MARK:- PUBLIC PROPERTIES
    
    //MARK:- PRIVATE PROPERTIES
    private var interactor: ItemListInteractor
    
    private var cancellables = Set<AnyCancellable>()
    private var router = ItemListRouter()
    
    //MARK:- PUBLIC OBSERVERS
    @Published var itemList: [Item] =  []
    
    //MARK:- CONSTRUCTOR
    init(interactor: ItemListInteractor) {
        self.interactor = interactor
        setupListener()
        loadItems()
    }
}

//MARK:- METHODS
extension ItemListPresenter {
    //MARK:- PUBLIC METHODS
    
    //MARK:- ROUTER METHODS
    func linkBuilder<Content: View>(for item: Item, @ViewBuilder content: () -> Content) -> some View {
        NavigationLink(destination: router.makeItemDetailView(for: item)) {
            content()
        }
        .buttonStyle(PlainButtonStyle())
    }
    
    //MARK:- PRIVATE METHODS
    private func setupListener() {
        interactor.$itemList
            .assign(to: \.itemList, on: self)
            .store(in: &cancellables)
    }
    
    private func loadItems() {
        interactor.loadItems()
    }
     
}


//MARK:- OBSERVABLE OBJECT
extension ItemListPresenter: ObservableObject { }
