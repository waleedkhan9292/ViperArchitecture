//
//  ViperTestSwiftUIApp.swift
//  ViperTestSwiftUI
//
//  Created by Waleed Waheed Khan on 20/04/2021.
//

import SwiftUI

@main
struct ViperTestSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
