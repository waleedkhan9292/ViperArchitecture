//
//  ContentView.swift
//  ViperTestSwiftUI
//
//  Created by Waleed Waheed Khan on 20/04/2021.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            ItemListVIew(
                presenter: ItemListPresenter(
                    interactor: ItemListInteractor()
                )
            )
            .navigationBarTitle("Items")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
