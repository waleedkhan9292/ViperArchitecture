//
//  ItemListVIew.swift
//  ViperTestSwiftUI
//
//  Created by Waleed Waheed Khan on 20/04/2021.
//

import SwiftUI

struct ItemListVIew: View {
    
    @ObservedObject var presenter: ItemListPresenter
    var body: some View {
        List {
            ForEach(presenter.itemList, id: \.id) { item in
                presenter.linkBuilder(for: item) {
                    Text(item.name)
                }
            }
        }
    }
}

struct ItemListVIew_Previews: PreviewProvider {
    static var previews: some View {
        ItemListVIew(presenter: ItemListPresenter(interactor: ItemListInteractor()))
    }
}
