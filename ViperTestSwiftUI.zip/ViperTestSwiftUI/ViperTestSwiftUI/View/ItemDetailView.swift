//
//  ItemDetailView.swift
//  ViperTestSwiftUI
//
//  Created by Waleed Waheed Khan on 21/04/2021.
//

import SwiftUI

struct ItemDetailView: View {
    @ObservedObject var presenter: ItemDetailPresenter
    var body: some View {
        
        VStack  {
            HStack {
                Text("Your item detail :")
                Spacer()
            }
            .padding(EdgeInsets(top: 10.0, leading: 10.0, bottom: 0.0, trailing: 10.0))
            HStack {
                Text(presenter.item?.name ?? "")
                Spacer()
                Text(presenter.item?.price ?? "")
            }
            .padding(EdgeInsets(top: 5.0, leading: 20.0, bottom: 0.0, trailing: 20.0))
            Spacer()
        }
        .navigationBarTitle("Item Detail", displayMode: .inline)
    }
    
}

struct ItemDetailView_Previews: PreviewProvider {
    static var previews: some View {
        ItemDetailView(presenter: ItemDetailPresenter(interactor: ItemDetailInteractor(item: Item(name: "Apple", price: "$20.0"))))
    }
}
