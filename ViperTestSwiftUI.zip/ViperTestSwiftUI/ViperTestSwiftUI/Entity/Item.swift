//
//  Item.swift
//  ViperTestSwiftUI
//
//  Created by Waleed Waheed Khan on 21/04/2021.
//

import Foundation


final class Item {
    
    @Published var name: String = ""
    @Published var price: String = ""
    
    let id: UUID
    
    init(name: String, price: String) {
        id = UUID()
        self.name = name
        self.price = price
    }
    
}


extension Item: ObservableObject {}
