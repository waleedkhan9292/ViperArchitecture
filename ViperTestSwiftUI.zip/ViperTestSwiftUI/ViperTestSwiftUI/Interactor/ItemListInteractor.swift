//
//  ItemListInteractor.swift
//  ViperTestSwiftUI
//
//  Created by Waleed Waheed Khan on 20/04/2021.
//

import Foundation

class ItemListInteractor {
    //MARK:- PUBLIC PROPERTIES
    
    
    //MARK:- PRIVATE PROPERTIES
    
    //MARK:- PUBLIC OBSERVERS
    @Published var itemList: [Item] = []
    
    //MARK:- CONSTRUCTOR
    init() {
    }
}

//MARK:- METHODS
extension ItemListInteractor {
    //MARK:- PUBLIC METHODS
    func loadItems() {
        itemList = [
            Item(name: "Apple", price: "$50.0"),
            Item(name: "Orange", price: "$20.0"),
            Item(name: "Grape", price: "$30.0"),
            Item(name: "Tomatoe", price: "$10.0"),
            Item(name: "Potato", price: "$20.0"),
            Item(name: "Onion", price: "$60.0"),
            Item(name: "Carrot", price: "$10.0"),
            Item(name: "Broccoli", price: "$5.0"),
            Item(name: "Spinach", price: "$2.0"),
            Item(name: "Corn", price: "$6.0")
        ]
    }
    
    //MARK:- ROUTER METHODS
    
    //MARK:- PRIVATE METHODS
     
}


//MARK:- OBSERVABLE OBJECT
extension ItemListInteractor: ObservableObject { }
