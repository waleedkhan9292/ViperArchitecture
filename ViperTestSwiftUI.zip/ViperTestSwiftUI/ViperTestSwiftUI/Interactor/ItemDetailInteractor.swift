//
//  ItemDetailInteractor.swift
//  ViperTestSwiftUI
//
//  Created by Waleed Waheed Khan on 21/04/2021.
//

import Foundation

class ItemDetailInteractor {
    //MARK:- PUBLIC PROPERTIES
    
    
    //MARK:- PRIVATE PROPERTIES
    
    //MARK:- PUBLIC OBSERVERS
    @Published var item: Item?
    
    //MARK:- CONSTRUCTOR
    init(item: Item) {
        self.item = item
    }
}

//MARK:- METHODS
extension ItemDetailInteractor {
    //MARK:- PUBLIC METHODS
    
    //MARK:- ROUTER METHODS
    
    //MARK:- PRIVATE METHODS
     
}


//MARK:- OBSERVABLE OBJECT
extension ItemDetailInteractor: ObservableObject { }
